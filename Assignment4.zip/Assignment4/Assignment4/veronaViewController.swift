//
//  veronaViewController.swift
//  Assignment4
//
//  Created by Kike Cordova on 2022-05-03.
//  Copyright © 2022 Derrick Park. All rights reserved.
//

import UIKit

class veronaViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .blue
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
